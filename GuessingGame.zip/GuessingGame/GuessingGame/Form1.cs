﻿/*Program Name: GuessingGame
 Date: 3/7/2022
Programer Name: Marko Miserda


Program Description: The program is a random number guessing game. The program introduces itself with
"I have a number between 1 and 100-can you guess my number?". The user is allowed to enter guesses into a text box
then guess by clicking the Guess button. When the user guesses closer to the random number the background turns red and 
tells the users if they are too high or low. The background will turn blue if the new guess is further away from the last guess.
The too high or low text will still appear no matter the guess. After guessing the right number the background will turn green and 
congratulate the user. The user then has the option to Restart to start a new game which will restest everything and pick a new
number, or the user can close the application.

Inputs: Guess

Outputs: TooHigh, TooLow, Correct, BackGroundRed, BackGroundBlue, BackGroundGreen

Givens: RandomNumber

Test Data: 
50; too high; red
20; too high; red
1; Too low; blue
10; Too low; Red
15; Too low, Red
18; too high, blue
16; Correct!; Green
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch14Ex8
{
    public partial class Form1 : Form
    {
        int guess = 0;
        static int number = 0;
        static string msg;
        static int diff = 0;
        static int diff2 = 1000;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            restart();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            guess = Convert.ToInt32(textBox1.Text);

            diff = Math.Abs(number - guess);

            if (diff2 >= diff)
            {
                this.BackColor = Color.Red;
                diff2 = diff;
            }
            else
            {
                this.BackColor = Color.Blue;
                diff2 = diff;
            }

            if (guess > number)
            {
                msg = "too high";
            }
            else if(guess < number)
            {
                msg = "Too low";
            }
            else
            {
                msg = "Correct!";
                this.BackColor = Color.Green;
                button1.Enabled = false;
                diff2 = 1000;
            }

            label2.Text = msg;

           
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void restart()
        {
            var rand = new Random();
            number = rand.Next(1, 100);
            button1.Enabled = true;
            textBox1.Clear();
           this.BackColor = Color.White;
            label2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            restart();
        }
    }
}
